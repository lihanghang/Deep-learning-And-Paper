cp eforest/forest.py scikit-learn/sklearn/ensemble/
cp eforest/_tree.pxd scikit-learn/sklearn/tree/
cp eforest/_tree.pyx scikit-learn/sklearn/tree/
cp eforest/tree.py scikit-learn/sklearn/tree/
